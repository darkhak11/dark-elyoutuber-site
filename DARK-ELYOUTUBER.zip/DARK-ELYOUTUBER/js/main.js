/* 💡 DARK ELYOUTUBER | main.js */
/* كود التحكم في حركة الموقع والمؤثرات */

document.addEventListener("DOMContentLoaded", () => {
  console.log("🔥 موقع دارك اليوتيوبر بدأ العمل بنجاح!");

  // 🌟 تأثير ظهور العناصر عند التمرير
  const reveals = document.querySelectorAll(".reveal");

  function revealOnScroll() {
    for (let i = 0; i < reveals.length; i++) {
      const windowHeight = window.innerHeight;
      const elementTop = reveals[i].getBoundingClientRect().top;
      const revealPoint = 150;

      if (elementTop < windowHeight - revealPoint) {
        reveals[i].classList.add("active");
      } else {
        reveals[i].classList.remove("active");
      }
    }
  }

  window.addEventListener("scroll", revealOnScroll);
  revealOnScroll();

  // 🌐 تفعيل التنقل السلس بين الأقسام
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener("click", function (e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute("href"));
      if (target) {
        target.scrollIntoView({ behavior: "smooth" });
      }
    });
  });

  // 🎵 مؤثرات صوتية عند الضغط (اختياري)
  const buttons = document.querySelectorAll("button, .btn");
  const clickSound = new Audio("assets/3d/click.mp3");

  buttons.forEach(btn => {
    btn.addEventListener("click", () => {
      clickSound.currentTime = 0;
      clickSound.play().catch(() => {});
    });
  });

  // 💫 تأثير تحريك اللوجو عند المرور عليه
  const logo = document.querySelector(".logo");
  if (logo) {
    logo.addEventListener("mouseenter", () => {
      logo.style.transform = "rotate(10deg) scale(1.1)";
    });
    logo.addEventListener("mouseleave", () => {
      logo.style.transform = "rotate(0) scale(1)";
    });
  }

  // 🌈 أنيميشن عشوائي على الأزرار
  const neonButtons = document.querySelectorAll(".btn");
  setInterval(() => {
    neonButtons.forEach(btn => {
      const glow = Math.random() > 0.5;
      btn.style.boxShadow = glow ? "0 0 20px #00ffff" : "none";
    });
  }, 1200);
});

/* 🔥 إضافة مؤثر reveal */
const style = document.createElement('style');
style.innerHTML = `
.reveal {
  opacity: 0;
  transform: translateY(30px);
  transition: all 0.8s ease;
}
.reveal.active {
  opacity: 1;
  transform: translateY(0);
}
`;
document.head.appendChild(style);