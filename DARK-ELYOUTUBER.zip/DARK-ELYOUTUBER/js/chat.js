/* 🤖 DARK ELYOUTUBER | chat.js */
/* ملف الذكاء الاصطناعي للشات */

document.addEventListener("DOMContentLoaded", () => {
  const chatBox = document.querySelector(".chat-box");
  const inputField = document.querySelector("#user-input");
  const sendBtn = document.querySelector("#send-btn");

  // 🎯 دالة لإضافة الرسائل في واجهة الشات
  function addMessage(message, sender) {
    const msg = document.createElement("div");
    msg.classList.add("message", sender);
    msg.innerHTML = `<p>${message}</p>`;
    chatBox.appendChild(msg);
    chatBox.scrollTop = chatBox.scrollHeight;
  }

  // ⚙️ ردود الذكاء الاصطناعي المبدئية (offline demo)
  function getAIResponse(userInput) {
    userInput = userInput.toLowerCase();

    if (userInput.includes("اهلا") || userInput.includes("هاي")) {
      return "أهلاً بيك في شات دارك اليوتيوبر 🔥 كيف أقدر أساعدك؟";
    } else if (userInput.includes("اسمك")) {
      return "أنا مساعد الذكاء الاصطناعي الخاص بـ DARK ALYOUTUBER 👑.";
    } else if (userInput.includes("كورسات")) {
      return "تقدر تشوف كل كورسات البرمجة واللغات في صفحة الكورسات 🎓.";
    } else if (userInput.includes("قناه")) {
      return "قناة DARK ALYOUTUBER على اليوتيوب متاحة هنا 🎥👇\nhttps://youtube.com/@dark_alyoutubr";
    } else if (userInput.includes("شكرا")) {
      return "العفو يا نجم 💙 نورت الموقع.";
    } else {
      const responses = [
        "ممم... سؤال جميل! جاري التفكير 🤔",
        "ممكن توضح أكتر؟",
        "حلو كلامك 🔥 بس محتاج تفاصيل أكتر.",
        "جميل جدًا 👑 تابعني وهرد عليك بالمعلومة قريب!",
      ];
      return responses[Math.floor(Math.random() * responses.length)];
    }
  }

  // 🚀 إرسال الرسالة
  sendBtn.addEventListener("click", sendMessage);
  inputField.addEventListener("keypress", (e) => {
    if (e.key === "Enter") sendMessage();
  });

  function sendMessage() {
    const userInput = inputField.value.trim();
    if (userInput === "") return;

    addMessage(userInput, "user");
    inputField.value = "";

    setTimeout(() => {
      const aiReply = getAIResponse(userInput);
      addMessage(aiReply, "bot");
    }, 700);
  }
});